@extends('layouts.app')

@section('content')
<div class="text-center">
    <h3>Ticket Tracker</h3>
    <h5>This project has been brought to you by Jonathan Disla (Web Developer)</h5>
    <img style ="border-radius:50%;" src="img/me.jpeg" alt="">
    <br>
    <br>
    <h5><a href="https://johndisla.com">Goto Website</a></h5>
</div>

@endsection