<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
    <div class="ticketForm">
        <?php echo Form::open(['action' => ['TicketsController@update',$ticket->id], 'method' => 'POST']); ?>

        <div class="row">
            <div class="col-sm-8">
                <div class="form-group">
                    <?php echo e(Form::label('shortname', 'Ticket Name')); ?>

                    <?php echo e(Form::text('shortname', $ticket->shortname, ['class' => 'form-control', 'readonly'])); ?>

                </div>
            </div>
            <div class="col-sm-4">
                <div class="form-group">
                    <?php echo e(Form::label('department', 'Department')); ?><br>
                    <?php echo e(Form::text('department', $ticket->department, ['class' => 'form-control', 'readonly'])); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-8">
                <div class="form-group">
                    <?php echo e(Form::label('name', 'Name')); ?>

                    <?php echo e(Form::text('name', $ticket->name, ['class' => 'form-control', 'readonly'])); ?>

                </div>
            </div>
            <div class="col-sm-4">
                <div class="form-group">
                    <?php echo e(Form::label('tel', 'Contact Number')); ?>

                    <?php echo e(Form::text('tel', $ticket->tel, ['class' => 'form-control', 'readonly'])); ?>

                </div>
            </div>
        </div>
        <div class="form-group">
            <?php echo e(Form::label('description', 'Description')); ?>

            <?php echo e(Form::textarea('description', $ticket->description, ['class' => 'form-control', 'placeholder' => 'Description'])); ?>

        </div>
            <div class="editBtns" style = "display:grid;grid-template-columns:100px 100px">
                <div class="editSubmitBtn">
                    <?php echo e(Form::hidden('_method', 'PUT')); ?>

                    <?php echo e(Form::submit('Edit', ['class' => 'btn btn-primary'])); ?>

                    <?php echo Form::close(); ?>

                </div>
                <div class="editDeleteBtn">
                    <?php echo Form::open(['action' => ['TicketsController@destroy',$ticket->id], 'method' => 'POST']); ?>

                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                    <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jon/Code/PHP/Laravel/ticketTracker/resources/views/tickets/edit.blade.php ENDPATH**/ ?>