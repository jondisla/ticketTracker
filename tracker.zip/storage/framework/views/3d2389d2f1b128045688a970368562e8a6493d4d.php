<div class="sidebar">
    <ul>
        <a href="/tickets"><li><img src="../../img/dash.png"> Dashboard</li></a>
        <a href="/tickets"><li><img src="../../img/tickets.png"> Tickets</li></a>
        <li><img src="../../img/people.png"> Teams</li>
        <li><img src="../../img/reports.png"> Reports</li>
    </ul>
</div><?php /**PATH /Users/jon/Code/PHP/Laravel/ticketTracker/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>