<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
    <?php if(count($tickets) > 0): ?>
    <h2>Open issues</h2>
            <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="minimizedCard">
        
        
        <div class="small timestamp">DATE: <?php echo e($ticket->created_at); ?>

        </div>
        <div class="buttons">
            <ul>
                <li><img src="img/danger.png" alt="Pending"></li>
                
                <li><img src="img/notcompleted.png" alt="Not Completed"></li>
            </ul>
        </div>
        <h4 class="card-title"><a href="/tickets/<?php echo e($ticket->id); ?>"><?php echo e($ticket->shortname); ?></a></h4>
        
        <div class="divider"></div>
        <div class="info">
            <div class="info1">
                Ticket ID: <?php echo e($ticket->id); ?>

            </div>
            <div class=info2" style="padding:20px 0">
                Department: <?php echo e($ticket->department); ?>

            </div>
            <div class="ticketDetail hidden" id="ticketDetail-<?php echo e($ticket->id); ?>">
                <p>Name: <?php echo e($ticket->name); ?></p>
                <p>Contact: <?php echo e($ticket->tel); ?></p>
                <?php echo e($ticket->description); ?>

            </div>
            <div class="details" id="plusBtn-<?php echo e($ticket->id); ?>" data-ticketId="<?php echo e($ticket->id); ?>">
                <img src="img/plus.png" alt="">
            </div>
            
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <h2>No Open issues</h2>
        <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jon/Code/PHP/Laravel/ticketTracker/resources/views/tickets/index.blade.php ENDPATH**/ ?>