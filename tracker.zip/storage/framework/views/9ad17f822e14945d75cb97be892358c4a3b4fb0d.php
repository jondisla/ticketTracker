<?php $__env->startSection('content'); ?>
<div class="text-center">
    <h3>Ticket Tracker</h3>
    <h5>This project has been brought to you by Jonathan Disla (Web Developer)</h5>
    <img style ="border-radius:50%;" src="img/me.jpeg" alt="">
    <br>
    <br>
    <h5><a href="https://johndisla.com">Goto Website</a></h5>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jon/Code/PHP/Laravel/ticketTracker/resources/views/pages/about.blade.php ENDPATH**/ ?>