<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
    <div class="minimizedCard">
        
        
        <div class="small timestamp">DATE: <?php echo e($tickets->created_at); ?>

        </div>
        <div class="buttons">
            <ul>
                <li><img src="../img/danger.png" alt="Pending"></li>
                <li></li>
                <li><img src="../img/checkmark.png" alt="Viewed"></li>
            </ul>
        </div>
        <h4 class="card-title"><a href="/tickets/<?php echo e($tickets->id); ?>"><?php echo e($tickets->shortname); ?></a></h4>
        
        <div class="divider"></div>
        <div class="info">
            <div class="info1">
                Ticket ID: <?php echo e($tickets->id); ?>

            </div>
            <div class=info2" style="padding:20px 0">
                Department: <?php echo e($tickets->department); ?>

            </div>
            <div class="ticketDetail" id="ticketDetail-<?php echo e($tickets->id); ?>">
                <p>Name: <?php echo e($tickets->name); ?></p>
                <p>Contact: <?php echo e($tickets->tel); ?></p>
                <?php echo e($tickets->description); ?>

            </div>
        </div>
    </div><a name="" id="editBtn" class="btn btn-primary" href="/tickets/<?php echo e($tickets->id); ?>/edit" role="button">Edit Ticket</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jon/Code/PHP/Laravel/ticketTracker/resources/views/tickets/show.blade.php ENDPATH**/ ?>