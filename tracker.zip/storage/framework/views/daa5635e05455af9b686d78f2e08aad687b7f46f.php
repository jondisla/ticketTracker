<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
    <h2>Open issues</h2>
    <div class="minimizedCard">
        
        <div class="small timestamp">Customer Name  |  DATE
        </div>
        <div class="buttons">
            <ul>
                <li><img src="img/danger.png" alt=""></li>
                <li><img src="img/clock.png" alt=""></li>
                <li><img src="img/checkmark.png" alt=""></li>
            </ul>
        </div>
        <h4 class="card-title">My Printer is not working</h4>
        <div class="divider"></div>
        <div class="info">
            <div class="info1">
                Ticket ID:
            </div>
            <div class=info2" style="padding:20px 0">
                Department:
            </div>
            <div class="details" id="plusBtn">
                <img src="img/plus.png" alt="">
            </div>
        </div>
        <div class="ticketDetail">
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Mollitia ad blanditiis, maiores eveniet doloremque a? Nostrum ex, cupiditate incidunt vel voluptatum quia illo, alias magni quae, aperiam recusandae fugiat! Ipsum.
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jon/Code/PHP/Laravel/ticketTracker/resources/views/pages/index.blade.php ENDPATH**/ ?>