<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">
    <h2>New Ticket</h2>
    <div class="ticketForm">
        <?php echo Form::open(['action' => 'TicketsController@store', 'method' => 'POST']); ?>

        <div class="row">
            <div class="col-sm-8">
                <div class="form-group">
                    <?php echo e(Form::label('shortname', 'Ticket Name')); ?>

                    <?php echo e(Form::text('shortname', '', ['class' => 'form-control', 'placeholder' => 'Printer stopped working'])); ?>

                </div>
            </div>
            <div class="col-sm-4">
                <div class="form-group">
                    <?php echo e(Form::label('department', 'Department')); ?><br>
                    <?php echo e(Form::select('department', ['IT' => 'IT', 'Support' => 'Support', 'Repair' => 'Repair'])); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-8">
                <div class="form-group">
                    <?php echo e(Form::label('name', 'Name')); ?>

                    <?php echo e(Form::text('name', '', ['class' => 'form-control', 'placeholder' => 'Customer name',])); ?>

                </div>
            </div>
            <div class="col-sm-4">
                <div class="form-group">
                    <?php echo e(Form::label('tel', 'Contact Number')); ?>

                    <?php echo e(Form::text('tel', '', ['class' => 'form-control', 'placeholder' => 'Ex: 1234567890'])); ?>

                </div>
            </div>
        </div>
        <div class="form-group">
            <?php echo e(Form::label('description', 'Description')); ?>

            <?php echo e(Form::textarea('description', '', ['class' => 'form-control', 'placeholder' => 'Description'])); ?>

        </div>
        <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jon/Code/PHP/Laravel/ticketTracker/resources/views/tickets/create.blade.php ENDPATH**/ ?>